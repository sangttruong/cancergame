This source code can be used to reproduce the numerical results reported in the manuscript:

M. Gluzman, J.G. Scott, and A. Vladimirsky,  Optimizing adaptive cancer therapy: dynamic programming and evolutionary game theory.
Proceedings of the Royal Society B: Biological Sciences 287: 20192454 (2020), https://doi.org/10.1098/rspb.2019.2454

In particular, it produces the optimal control and value function from Figure 3 of the manuscript.